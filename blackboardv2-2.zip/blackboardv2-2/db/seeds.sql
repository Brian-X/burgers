use sequelize_passportdb;
insert into users(firstname,lastname,username,about,email,password,status,studentloginType,adminloginType,createdAt,updatedAt) 
values("vic","doe","vicdoe@gmail.com","F","vicdoe@gmail.com","abc","active",true,false,'2016-01-04 02:33:04','2016-01-04 02:33:04');
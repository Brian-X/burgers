-- ### Schema
DROP DATABASE IF EXISTS sequelize_passportdb;
CREATE DATABASE sequelize_passportdb;
USE sequelize_passportdb;

-- CREATE TABLE yum
-- (
-- 	id int NOT NULL AUTO_INCREMENT,
-- 	burger_name varchar(255) NOT NULL,
-- 	devoured  BOOLEAN DEFAULT false,
-- 	date TIMESTAMP,
-- 	PRIMARY KEY (id)
-- );
